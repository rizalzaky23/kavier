import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../features/kasir/data/models/transaction_model.dart';

class PrinterService {
  final BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;
  final NumberFormat _fmt = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  /// Meminta seluruh izin yang dibutuhkan untuk Bluetooth (Android 12+)
  Future<bool> checkPermissions() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();

    bool allGranted = true;
    for (var status in statuses.values) {
      if (!status.isGranted) allGranted = false;
    }
    return allGranted;
  }

  /// Mendapatkan daftar perangkat bluetooth yang sudah di-pair
  Future<List<BluetoothDevice>> getPairedDevices() async {
    bool? isOn = await bluetooth.isOn;
    if (isOn != true) {
      throw Exception('Bluetooth tidak aktif');
    }
    List<BluetoothDevice> devices = [];
    try {
      devices = await bluetooth.getBondedDevices();
    } catch (e) {
      // Ignored
    }
    return devices;
  }

  /// Menghubungkan ke perangkat printer
  Future<void> connect(BluetoothDevice device) async {
    bool? isConnected = await bluetooth.isConnected;
    if (isConnected == true) {
      await bluetooth.disconnect();
    }
    await bluetooth.connect(device);
  }

  /// Mencetak format Nota dengan lebar kertas default (kurang lebih 32 karakter per baris untuk 58mm)
  Future<void> printReceipt(TransactionModel transaction, List<dynamic> items) async {
    bool? isConnected = await bluetooth.isConnected;
    if (isConnected != true) {
      throw Exception('Printer belum terhubung');
    }

    try {
      // HEADER
      bluetooth.printNewLine();
      bluetooth.printCustom('UR FARM POS', 2, 1); // 2=size, 1=center
      bluetooth.printCustom('Jl. Pertanian Raya No. 123', 0, 1);
      bluetooth.printCustom('Kota Agrikultur', 0, 1);
      bluetooth.printCustom('--------------------------------', 0, 1);

      // INFO TRANSAKSI
      DateTime dt = DateTime.tryParse(transaction.createdAt) ?? DateTime.now();
      bluetooth.printLeftRight(
          'No: ${transaction.invoiceNumber}',
          DateFormat('dd/MM/yy HH:mm').format(dt),
          0);
      bluetooth.printCustom('Kasir: Admin', 0, 0); // TODO: Bisa sesuaikan dengan user yang login
      bluetooth.printCustom('--------------------------------', 0, 1);

      // DAFTAR ITEM
      for (var item in items) {
        // Nama produk (potong jika terlalu panjang)
        String name = item.name.length > 20 ? item.name.substring(0, 20) : item.name;
        
        bluetooth.printCustom(name, 0, 0); // Kiri
        
        String qtyPrice = '${item.quantity} x ${_fmt.format(item.price)}';
        String subtotal = _fmt.format(item.subtotal);
        bluetooth.printLeftRight(qtyPrice, subtotal, 0);
      }
      bluetooth.printCustom('--------------------------------', 0, 1);

      // TOTALS
      bluetooth.printLeftRight('Subtotal', _fmt.format(transaction.total), 0);
      if (transaction.discount > 0) {
        bluetooth.printLeftRight('Diskon', '- ${_fmt.format(transaction.discount)}', 0);
      }
      
      bluetooth.printCustom('--------------------------------', 0, 1);
      bluetooth.printLeftRight('Total', _fmt.format(transaction.total), 1); // 1 = Size 1
      bluetooth.printLeftRight('Dibayar', _fmt.format(transaction.paidAmount), 0);
      bluetooth.printLeftRight('Kembalian', _fmt.format(transaction.changeAmount), 0);
      
      bluetooth.printCustom('--------------------------------', 0, 1);
      
      // FOOTER
      bluetooth.printNewLine();
      bluetooth.printCustom('Terima Kasih', 1, 1);
      bluetooth.printCustom('Barang yang sudah dibeli', 0, 1);
      bluetooth.printCustom('tidak dapat ditukar', 0, 1);
      bluetooth.printNewLine();
      bluetooth.printNewLine();
      bluetooth.printNewLine();
      
      bluetooth.paperCut(); // Opsional, cut paper
    } catch (e) {
      throw Exception('Gagal mencetak: $e');
    }
  }

  Future<void> disconnect() async {
    await bluetooth.disconnect();
  }
}
